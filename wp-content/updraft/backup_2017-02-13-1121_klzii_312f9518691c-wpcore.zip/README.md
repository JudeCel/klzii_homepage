	    __  _______     _       ______     ____        _ __                __      __     
	   /  |/  / __ \   | |     / / __ \   / __ )____  (_) /__  _________  / /___ _/ /____ 
	  / /|_/ / /_/ /   | | /| / / /_/ /  / __  / __ \/ / / _ \/ ___/ __ \/ / __ '/ __/ _ \
	 / /  / / _, _/    | |/ |/ / ____/  / /_/ / /_/ / / /  __/ /  / /_/ / / /_/ / /_/  __/
	/_/  /_/_/ |_|     |__/|__/_/      /_____/\____/_/_/\___/_/  / .___/_/\__,_/\__/\___/ 
	                                                            /_/

WordPress Boilerplate for Marketing Results
===========================================

A Wordpress /wp-content boilerplate for Marketing Results projects. Includes the essential theme and plugins for development.
It comes with an up-to-date version of the Genesis Theme along with a simplified (kickstart) version of the Genesis Sample Theme.

Installation
------------

You have two options:

* You can clone this Git repository
* Downloading it directly as a .zip file

Replace and overwrite /wp-content on your WP installation with the one from this package.

Bonus:

* `.htaccess` modifications based on MR specs. Copy `.htaccess` to the root of your WP installation. Set your WP Permalinks setting to "Post Name".


Post-Installation
-----------------

Add these lines to your wp-config.php to implement dynamic base urls.

	:::php
	<?php
	define('WP_SITEURL', "http://{$_SERVER['HTTP_HOST']}");
	define('WP_HOME', "http://{$_SERVER['HTTP_HOST']}");


Essential Plugins
-----------------

These plugins are included by default:

* [WP Google Authorship](http://mervin.info/google-plus-author)
* [Google XML Sitemaps](http://www.arnebrachhold.de/redir/sitemap-home/)
* [Visual Website Optimizer](http://visualwebsiteoptimizer.com/)
* [Custom Permalinks](http://atastypixel.com/blog/wordpress/plugins/custom-permalinks/)
* [Dynamic Widgets](http://dynamic-widgets.com/)
* [Gravity Forms](http://www.gravityforms.com/) - Proprietary
* [PHP Code Widget](http://ottopress.com/wordpress-plugins/php-code-widget/)
* [Shortcodes in Sidebar Widgets](http://resultzdigital.com/wordpress-plugins/)
* [ShortCodes UI](http://en.bainternet.info/)
* [Toggle The Title](http://wordpress.org/extend/plugins/toggle-the-title/)
* [Toggle wpautop](http://wordpress.org/extend/plugins/toggle-wpautop)
* Default WP plugins, [Akismet](http://akismet.com/) and [Hello Dolly](http://wordpress.org/plugins/hello-dolly/)

[W3 Total Cache](https://wordpress.org/plugins/w3-total-cache/) and [Wordfence](https://wordpress.org/plugins/wordfence/) aren't included in this package due to file sizing.
However, it is better to install these two plugins on the live and staging servers as they should be there anyway, not locally.
[Yoast](https://yoast.com/wordpress/plugins/seo/) is also excluded as Genesis already includes an SEO functionality.


Additional Plugins
------------------

These are additional plugins for the package:

* **Genesis Hooks Debugger (beta)** - A custom plugin for generating outlines on Genesis hooks and lists currently attached functions with their priority, making it a map for overrides. The outlines only show when admin is logged in.
* [WP-SCSS](https://wordpress.org/plugins/wp-scss/) - PHP-based SASS compiler for Wordpress


SCSS
----

Recommended directory structure:

    themeDirectory/
      images/
      style.css (Blank CSS used only for declaring the theme)
      main.css (The path to compile the SCSS to. This is compiled and ignored in version control)
      scss/
        | _containers.scss
        | _forms.scss
        | _grid.scss
        | _lists.scss
        | _media-queries.scss
        | _mixins.scss
        | _normalize.scss
        | _scaffolding.scss
        | _site-content.scss
        | _site-footer.scss
        | _site-header.scss
        | _site-main.scss
        | _site-navigation.scss
        | _site-sidebar.scss
        | _type.scss
        | _utility.scss
        | _variables.scss
        | _wordpress.scss
        | main.scss

WP-SCSS Settings:

* **Scss Location** - `/scss/` 
* **CSS Location** - `/` 
* **Compiling Mode** - Compressed 
* **Error Display** - Show to Logged In Users 
* **Enqueue Stylesheets** - (uncheck as we'll handle the setup inside `functions.php`) 

`functions.php` code that sets up our stylesheets based from our WP-SCSS configuration:

    :::php
    <?php
    //* WP-SCSS settings
    if( class_exists('scssc') &&
        // Compilation dir should be on theme root
        $css_dir_setting === '/' &&
        // Enqueue should be turned off
        !$wpscss_options['enqueue']
    ) {
        //* Remove default style.css
        remove_action( 'genesis_meta', 'genesis_load_stylesheet' );
        //* Manually enqueue compiled CSS
        add_action( 'wp_enqueue_scripts', 'enqueue_scss' );
        function enqueue_scss() {
            $handle   = defined( 'CHILD_THEME_NAME' ) && CHILD_THEME_NAME ? sanitize_title_with_dashes( CHILD_THEME_NAME ) : 'child-theme';
            $scss_ver = filemtime( get_stylesheet_directory() . '/main.css' );
            wp_enqueue_style( $handle, get_stylesheet_directory_uri().'/main.css', array(), $scss_ver  );
        }
    }

Note that `style.css` will now be only used to name the theme. The `main.css` file, which is compiled by WP-SCSS, will be our main stylesheet. It's also ignored in version control.


Contributions
-------------

This project only allows contributions from the MR Tech Team.


Author
------

**.czt** for the MR Tech team
